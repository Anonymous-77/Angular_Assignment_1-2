import { DateinputconverterDirective } from './dateinputconverter.directive';

describe('DateinputconverterDirective', () => {
  it('should create an instance', () => {
    const directive = new DateinputconverterDirective();
    expect(directive).toBeTruthy();
  });
});
